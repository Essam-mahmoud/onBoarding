//
//  ViewController.swift
//  onboarding
//
//  Created by Apple on 12/29/19.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var pageControl: UIPageControl!
    var imagArray = [UIImage]()
    @IBOutlet weak var detStartButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        scrollView.delegate = self
        imagArray = [#imageLiteral(resourceName: "image3"),#imageLiteral(resourceName: "image1"),#imageLiteral(resourceName: "image2")]
        scrollView.contentSize.width = self.view.frame.width * CGFloat(imagArray.count)
        scrollView.frame.size = self.view.frame.size
        scrollView.isPagingEnabled = true
        scrollView.showsHorizontalScrollIndicator = false
        for n in 0 ..< imagArray.count{
            let imageView = UIImageView()
            imageView.image = imagArray[n]
            let xPostion = self.view.frame.width * CGFloat(n)
            imageView.frame = CGRect(x: xPostion, y: 0, width: scrollView.frame.width, height: scrollView.frame.height)
            imageView.contentMode = .scaleToFill
            scrollView.addSubview(imageView)
        }
        
        
        // Do any additional setup after loading the view.
    }

    @IBAction func getStartButtonPressed(_ sender: UIButton) {
        UserDefaults.standard.set(true, forKey: "onBoardingCompelete")
        UserDefaults.standard.synchronize()
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "MainViewController") as! MainViewController
        vc.modalTransitionStyle = .flipHorizontal
        present(vc, animated: true, completion: nil)
    }
}

extension ViewController: UIScrollViewDelegate{
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let page = scrollView.contentOffset.x / scrollView.frame.width
        pageControl.currentPage = Int(page)
        
        if page == 2{
            UIView.animate(withDuration: 0.4) {
                self.detStartButton.alpha = 1
            }
        }else{
            UIView.animate(withDuration: 0.1) {
                self.detStartButton.alpha = 0
            }
        }
        
    }
    
}

